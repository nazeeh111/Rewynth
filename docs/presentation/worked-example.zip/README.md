# Rewynth recorded model comparison

Parent e9f4261b9ffda97186fa1ced4cbcfc6a78516189. Current generated C and authored caller, not the original pointer ABI. The bundled fixture is only data for recovery and is never loaded or executed by this example.

With Python3.11+ and an existing C11 compiler, run in this fresh directory:

    python3 rebuild.py

The script compiles only original.c, edited.c and caller.c in a temporary directory, executes the generated model caller and compares the exact continuation results with browser.json. No Rewynth, Capstone or Z3 runtime is needed for this generated-source check.
Recorded native-caller.json describes the original build; absolute source/temporary paths and compiler metadata may differ on replay. Check source hashes and numeric results, not a regenerated execution record's whole-file hash.
comparison.json/workspace.rewynth bind the source artifact and declared input domain. The workspace embeds exactly fixture-pcg-basic.o; use the installed current Rewynth workbench to reopen and perform a fresh comparison. Opening does not establish a fresh proof.

Original PCG32 source: Melissa O'Neill, PCG C basic revision bc39cd76ac3d541e618606bcc6e1e5ba5e5e6aa3. Apache2.0 notice retained as PCG-LICENSE.txt. Original Rewynth code/source models MIT, see REWYNTH-LICENSE.txt. Capstone and Z3 retain their own licenses in an installed Rewynth environment. The lost-store edit is ours; no PCG defect, random-quality, seed-recovery or CPU-lifter proof is claimed.

All MANIFEST.json paths are included. The two logical uint64 inputs are initial state and increment. One pointer, two little-endian words at a fixed synthetic base0x100000000. The next calls use the original transition from each respective post-state.
